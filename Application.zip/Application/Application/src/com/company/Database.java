package com.company;
import java.sql.*;

public class Database {


    private static Database instance = new Database();//getting the instance of the database
    public static Database returnInstance(){//return instance method for using database within our program
        return instance;
    }

    String connectionUrl = "jdbc:postgresql://localhost:5432/Android app"; //getting url of existing database postgresql
    Connection con = null;//connection
    ResultSet rs = null;//collection of results returned during queries execution session
    Statement stmt = null;//statement that we`ll be using to create queries

    private Database(){

        try {
            //Import postgresql driver
            Class.forName("org.postgresql.Driver");
            //establish connection
            con = DriverManager.getConnection(connectionUrl, "postgres","1249");

        }
        catch (SQLException | ClassNotFoundException throwables){
            throwables.printStackTrace();//throw exception in case errors related to connection between dbms and java
        }
    }



    public boolean addUser(int user_id, String nickname, String password, String email) { //Query to add new user to database
        String stat = "insert into users(user_id, nickname,password,email) values(?,?,?,?)"; //prepared statement to create new user
        try {
            PreparedStatement preparedStatement = con.prepareStatement(stat);//pass the query through connection
            preparedStatement.setInt(1, user_id);//input and pass values
            preparedStatement.setString(2, nickname);
            preparedStatement.setString(3, password);
            preparedStatement.setString(4, email);
            if (preparedStatement.executeUpdate() > 0) {//in case everything went smoothly return true
                return true;
            }
            preparedStatement.close();
        } catch (SQLException e) { //in case exception occurs return it
            e.printStackTrace();//catch block to be able to respond to the errors and fix the code.
        }
        return false;//return false in case something went wrong
    }
}