package com.company;

public class Main {
    public static final Developer dev = new Developer();

    public static void main(String[] args) {
        dev.addUser();
    }
}
