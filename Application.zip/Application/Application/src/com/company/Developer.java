package com.company;

import java.sql.SQLException;
import java.util.Scanner;

public class Developer {
    Database db = Database.returnInstance();//get instance of the database to pass values directly
    Scanner sc = new Scanner(System.in);//scanner for input


    public void addUser(){ //adding user method
        System.out.println("Enter id"); //user id
        int user_id = sc.nextInt();
        System.out.println("Enter nickname");//users nickname
        String nickname = sc.next();
        System.out.println("Enter email-address");//email address
        String email = sc.next();
        System.out.println("Enter password");//password
        String password = sc.next();
        System.out.println("Repeat password");//repeat password
        String password2 = sc.next();

        if(password.equals(password2)){         //check whether password are matching
            if(db.addUser(user_id,nickname,password,email)){ //adding new user in case passwords are matching
                System.out.println("New user has been successfully created!");//output
            } else {
                System.out.println("Please try again");//try again message
            }
        }
        else{
            System.out.println("Invalid input!!!");//else output invalid input
        }
    }
}