package com.company;

import java.sql.SQLException;

public class Main {
    public static final Developer dev = new Developer();

    public static void main(String[] args) throws SQLException {

       dev.adminPannel();

    }
}

