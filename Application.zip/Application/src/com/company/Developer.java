package com.company;

import java.sql.SQLException;
import java.util.Scanner;

public class Developer {
    Database db = Database.returnInstance();//get instance of the database to pass values directly
    Scanner sc = new Scanner(System.in);//scanner for input

//////////////////////  U S E R \\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
    public void addUser(){ //adding user method
        System.out.println("Enter id"); //user id
        int user_id = sc.nextInt();
        System.out.println("Enter nickname");//users nickname
        String nickname = sc.next();
        System.out.println("Enter email-address");//email address
        String email = sc.next();
        System.out.println("Enter password");//password
        String password = sc.next();
        System.out.println("Repeat password");//repeat password
        String password2 = sc.next();

        if(password.equals(password2)){         //check whether password are matching
            if(db.addUser(user_id,nickname,password,email)){ //adding new user in case passwords are matching
                System.out.println("New user has been successfully created!");//output
            } else {
                System.out.println("Please try again");//try again message
            }
        }
        else{
            System.out.println("Invalid input!!!");//else output invalid input
        }
    }


    public void printAll(){//out printing all inside the database
        try {
            db.printUsers();
        }
        catch (SQLException e){//catch exception
            e.printStackTrace();
        }
    }

    public void printSpecificUser() throws SQLException {//removing config by id
        System.out.println("Enter ID");
        int id = sc.nextInt();//get id of config
        try {
            db.printSpecificUser(id);
        }
        catch (SQLException e){
            e.printStackTrace();
        }
    }

    public void RemoveUser(){//removing config by id
        System.out.println("Enter ID");
        int userId = sc.nextInt();//get id of config
        if(db.deleteUser(userId)){//pass it to remove config from database
            System.out.println("User has been removed");

        }
        else {//in case fail try again message pop up
            System.out.println("try again...");
        }
    }

    public void authorization() throws SQLException {
        final String adminNick = "admin";
        final String adminPass = "pass";
        System.out.println("Enter nickname");
        String nickname = sc.next();
        System.out.println("Enter password");
        String password = sc.next();
        if(nickname.equals(adminNick) && password.equals(adminPass)){
            System.out.println("Welcome to the board captain!!!");
            adminPannel();
        }
        else {
            try {
                if(db.authorization(password, nickname)){
                    System.out.println("Hello, " + nickname);
                    menu(password,nickname);//reversed pay attention
                }
                else {
                    System.out.println("Incorrect password/nickname");
                }

            } catch (SQLException e) {
                e.printStackTrace();
            }
        }



    }

    public void changePass(String password, String nickname){
        System.out.println("Enter current password");
        String oldPass = sc.next();
        if(password.equals(oldPass)){
            System.out.println("Enter new password");
            String newPass = sc.next();
            System.out.println("Verify your password");
            String repPass = sc.next();
            try {
                if(db.changePassword(newPass, nickname, password)) {
                    System.out.println("Password has changed...");
                }
                else {
                    System.out.println("Please try again...");
                }
            } catch (SQLException e) {

                e.printStackTrace();
            }
        }
        else {
            System.out.println("We will sue you for trying to hack us!!!");
        }
    }

    public void changeNick(String password, String nickname){
        System.out.println("Enter current password");
        String pass = sc.next();
        if(password.equals(pass)){
        System.out.println("Enter new name");
        String newnick = sc.next();

        try {
            if(db.changeNickname(newnick, nickname, password)){
                System.out.println("Update complete... nickname has changed to, " + newnick);
            }
            else {
                System.out.println("Try again");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        }
        else {
            System.out.println("Incorrect password/nickname");
        }
    }






    ////// R E C O R D S \\\\\\\\
    public void printRecords(){
        final Scanner scn = new Scanner(System.in);
        int MenuNum = 0;
        System.out.println("\n1.Table style\n2.Statistical report\n3.Graph style \n4.Close");
            MenuNum=scn.nextInt();
            switch (MenuNum) {
                case 1:
                    printTBRecords();
                    break;
                case 2:
                    printGrRecords();
                    break;
                case 3:
                    break;
                case 0:
                default:
                    System.out.println("Please chose one of the options!");
                    break;
        }
    }



    public void printTBRecords(){//out printing all inside the database
        System.out.println("Enter user ID");
        int user_id = sc.nextInt();

        try {
            db.recordTable(user_id);
        }
        catch (SQLException e){//catch exception
            e.printStackTrace();
        }
    }

    public void printGrRecords(){//out printing all inside the database
        System.out.println("Enter user ID");
        int user_id = sc.nextInt();

        try {
            db.recordStatistical(user_id);
        }
        catch (SQLException e){//catch exception
            e.printStackTrace();
        }
    }





    public void addRecord() throws SQLException { //adding user method
        System.out.println("Enter user_id:"); //user id
        int userID = sc.nextInt();
        System.out.println("Choose category:");//users nickname
        db.showCategories();

        int cat = sc.nextInt();

        System.out.println("Now choose subcategory:");
        db.showSubcategories(100+cat);
        int sub = sc.nextInt();
        System.out.println("Amount of money");
        int money = sc.nextInt();
        System.out.println("Do you want to update or add new record?");
        System.out.println("Press 1 to add 2 to update");
        int enter = sc.nextInt();
        int choice = enter-1;

        if(choice==1){
            if(db.recordUpdate(userID,db.returnSubId(db.returnSub(100+cat, sub)), money)){
                System.out.println("Updated!");
            }
            else {
                System.out.println("Please try again");//try again message
            }
        }
        else{
            if(db.recordAdd(userID,db.returnSubId(db.returnSub(100+cat, sub)), money)){ //adding new record
                System.out.println("New record has been successfully added!");//output
            } else {
                System.out.println("Please try again");//try again message
            }
        }
    }

    public void removeRecord() throws SQLException { //adding user method
        System.out.println("Enter user_id:"); //user id
        int userID = sc.nextInt();
        System.out.println("Which record should be deleted:");//users nickname
        db.recordTable(userID);
        int record = sc.nextInt();


        if(db.recordRemove(userID, db.returnSubId(db.returnRecName(userID,record)))){ //adding new record
            System.out.println("Record has been successfully removed!");//output
        } else {
            System.out.println("Please try again");//try again message
        }

    }




    public void menu(String password, String nickname){
        final Scanner scn = new Scanner(System.in);
        int MenuNum = 0;
        while (MenuNum != 5){ System.out.println("\nHello, world!\n1.Change the password\n2.Change nickname\n3.Add to wallet \n4.Remove from wallet \n5.Print the report \n6.Log out");
            MenuNum=scn.nextInt();
            switch (MenuNum) {
                case 1:
                    System.out.println("Change the password");
                    changePass(password, nickname );
                    System.exit(0);
                case 2:
                    System.out.println("Change nickname");
                    changeNick(password, nickname);
                    System.exit(0);
                case 3:
                    System.out.println("Add to wallet");
                    RemoveUser();
                    break;
                case 4:
                    System.out.println("Remove from wallet");
                    printAll();
                case 5:
                    System.out.println("Show the report");
                    break;
                case 6:
                    System.out.println("Exiting the program...");
                    System.exit(0);
                case 0:
                default:
                    System.out.println("Please chose one of the options!");
                    break;
            }
        }
    }


    public void adminPannel() throws SQLException {
        final Scanner scn = new Scanner(System.in);
        int MenuNum = 0;
        while (MenuNum != 8){ System.out.println("\nHello, world!\n1.Remove user\n2.Show user by id\n3.Show all users\n4.Add user\n5.Show report on User\n6.Add new record\n7.Remove record\n8.Log out");
            MenuNum=scn.nextInt();
            switch (MenuNum) {
                case 1:
                    System.out.println("Removing user");
                    RemoveUser();
                    break;
                case 2:
                    System.out.println("Showing user by id");
                    printSpecificUser();
                    break;
                case 3:
                    printAll();
                    break;
                case 4:
                    addUser();
                    break;
                case 5:
                    printRecords();
                    break;
                case 6:
                    addRecord();
                    break;
                case 7:
                    removeRecord();
                    break;
                case 8:
                    System.out.println("Exiting the program...");
                    System.exit(0);
                case 0:
                default:
                    System.out.println("Please chose one of the options!");
                    break;
            }
        }
    }

}