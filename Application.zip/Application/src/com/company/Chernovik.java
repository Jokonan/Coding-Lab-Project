package com.company;

import java.util.Scanner;

public class Chernovik {
/*
    public void menu(){
        final Scanner scn = new Scanner(System.in);
        int MenuNum = 0;
        while (MenuNum != 5){ System.out.println("\nHello, world!\n1.Change the password\n2.Change nickname\n3.Add to wallet \n 4.remove from wallet \n5.Print the report \n6.Exit");
            MenuNum=scn.nextInt();
            switch (MenuNum) {
                case 1:
                    System.out.println("Add new user");
                    addUser();
                    break;
                case 2:
                    System.out.println("Print users");
                    printAll();
                    break;
                case 3:
                    System.out.println("Delete user");
                    RemoveUser();
                    break;
                case 4:
                    System.out.println("Change nickname");
                    changeNick();
                case 5:
                    System.out.println("Exiting the program...");
                    System.exit(0);
                    break;
                case 0:
                default:
                    System.out.println("Please chose one of the options!");
                    break;
            }
        }
    }

 */
}
