package com.company;
import java.sql.*;

public class Database {


    private static Database instance = new Database();//getting the instance of the database
    public static Database returnInstance(){//return instance method for using database within our program
        return instance;
    }

    String connectionUrl = "jdbc:postgresql://localhost:5432/Android app"; //getting url of existing database postgresql
    Connection con = null;//connection
    ResultSet rs = null;//collection of results returned during queries execution session
    Statement stmt = null;//statement that we`ll be using to create queries

    private Database(){

        try {
            //Import postgresql driver
            Class.forName("org.postgresql.Driver");
            //establish connection
            con = DriverManager.getConnection(connectionUrl, "postgres","1249");

        }
        catch (SQLException | ClassNotFoundException throwables){
            throwables.printStackTrace();//throw exception in case errors related to connection between dbms and java
        }
    }



    public boolean addUser(int user_id, String nickname, String password, String email) { //Query to add new user to database
        String stat = "insert into users(user_id, nickname,password,email) values(?,?,?,?)"; //prepared statement to create new user
        try {
            PreparedStatement preparedStatement = con.prepareStatement(stat);//pass the query through connection
            preparedStatement.setInt(1, user_id);//input and pass values
            preparedStatement.setString(2, nickname);
            preparedStatement.setString(3, password);
            preparedStatement.setString(4, email);
            if (preparedStatement.executeUpdate() > 0) {//in case everything went smoothly return true
                return true;
            }
            preparedStatement.close();
        } catch (SQLException e) { //in case exception occurs return it
            e.printStackTrace();//catch block to be able to respond to the errors and fix the code.
        }
        return false;//return false in case something went wrong
    }


    public void printUsers() throws SQLException {

        String sql = "select * from users";//select all data from catalog database
        Statement st = con.createStatement();//establish connection
        ResultSet rs = st.executeQuery(sql);//pass the query

        if(rs.next()){//do until the end of the table
            do{
                System.out.println(rs.getInt(1) +"|" + rs.getString(2)+"|"+rs.getString(3)+"|"+rs.getString(4)+"|");
            }while(rs.next());
        }
        else{
            System.out.println("Record does not exist...");//if values does not exist
        }

    }

    public void printSpecificUser(int id) throws SQLException {
        String sql = "Select * from users where user_id=" + id;//query for selecting specific user from database
        Statement st = con.createStatement();//establish connection
        ResultSet rs = st.executeQuery(sql);//pass the query

        if(rs.next()) {//do if exists in the table
            System.out.println(rs.getInt(1) + "|" + rs.getString(2) + "|" + rs.getString(3) + "|" + rs.getString(4) + "|");
        }
        else{
            System.out.println("Record does not exist...");//if values does not exist
        }


    }

    public boolean deleteUser(int id) {
        String sql = "delete from users where user_id=?";//query for deleting item from database
        try {
            PreparedStatement preparedStatement = con.prepareStatement(sql);//pass query through connection
            preparedStatement.setInt(1, id);//deleting by accessing through id
            if (preparedStatement.executeUpdate() > 0) { //if deleting went successfully return true
                return true;
            }
            preparedStatement.close();
        } catch (SQLException e) {//catching exception in case error
            e.printStackTrace();
        }
        return false;//return false otherwise
    }




    public boolean authorization(String password, String nickname) throws SQLException {
        String sql = "SELECT * from users WHERE nickname='" + nickname + "' and password='" + password +"'"; //query that is being executed
        Statement st = con.createStatement();//establish connection
        ResultSet rs = st.executeQuery(sql);//pass the query

        if( rs.next()){ //if exists return true
            return true;
        } else { //else case return false
            return false;
        }
    }

    public boolean changeNickname(String newNick, String nickname, String password) throws SQLException {
        String sql = "UPDATE users SET nickname='" + newNick + "' WHERE nickname='" + nickname + "' and password='" + password+"'";
        Statement st = con.createStatement();//establish connection
        try{
            st.executeUpdate(sql);//pass the query
            return true;
        }
        catch (Exception e){
            return false;
        }
    }

    public boolean changePassword(String newPassword, String nickname, String password) throws SQLException {
        String sql = "UPDATE users SET password='" + newPassword + "' WHERE nickname='" + nickname + "' and password='" + password+"'";
        Statement st = con.createStatement();//establish connection
        try{
            st.executeUpdate(sql);//pass the query
            return true;
        }
        catch (Exception e){
            return false;
        }

    }


    public void recordTable(int user_id) throws SQLException {
        String sql = "SELECT s.name AS Subcategory, c.name AS Category, w.expenses FROM Wallet AS W INNER JOIN subcategories AS S ON  w.sub_id=s.sub_id INNER JOIN categories AS C ON S.parent_id = c.categories_id WHERE W.user_id =" + user_id;
        Statement st = con.createStatement();//establish connection
        ResultSet rs = st.executeQuery(sql);//pass the query
        int ind = 0;
        if(rs.next()) {//do if exists in the table
            do{
                ind++;
                System.out.println("|" + ind + ". " + rs.getString(1) + "| Основная категория:" + rs.getString(2) + "| Потрачено " + rs.getInt(3) + "$ |");
            }while(rs.next());
        }
        else{
            System.out.println("Records do not exist...");//if values does not exist
        }

    }

    public void recordStatistical(int user_id) throws SQLException {
        String sql = "SELECT s.name AS Subcategory, c.name AS Category, w.expenses FROM Wallet AS W INNER JOIN subcategories AS S ON  w.sub_id=s.sub_id INNER JOIN categories AS C ON S.parent_id = c.categories_id WHERE W.user_id =" + user_id;
        Statement st = con.createStatement();//establish connection
        ResultSet rs = st.executeQuery(sql);//pass the query

        int sum = sumRecords(user_id);

        if(rs.next()) {//do if exists in the table
            do{
                System.out.println("|"  + rs.getString(1) + "| Основная категория:" + rs.getString(2) + "| Потрачено " + Math.round(rs.getInt(3)*100.0/sum) + "% |");
            }while(rs.next());
        }
        else{
            System.out.println("Records do not exist...");//if values does not exist
        }

    }

    public int sumRecords(int user_id) throws SQLException {
        String sql = "SELECT s.name AS Subcategory, c.name AS Category, w.expenses FROM Wallet AS W INNER JOIN subcategories AS S ON  w.sub_id=s.sub_id INNER JOIN categories AS C ON S.parent_id = c.categories_id WHERE W.user_id =" + user_id;
        Statement st = con.createStatement();//establish connection
        ResultSet rs = st.executeQuery(sql);//pass the query

        int sum = 0;
        if(rs.next()) {//do if exists in the table
            do{
                sum += rs.getInt(3);


            }while(rs.next());
        }

        return sum;
    }

    public boolean recordUpdate(int user_id, int sub_id, int amount) throws SQLException {
        String sql = "UPDATE wallet SET expenses='" + amount + "' WHERE user_id='" + user_id + "' and sub_id='" + sub_id+"'";
        Statement st = con.createStatement();//establish connection
        try{
            st.executeUpdate(sql);//pass the query
            return true;
        }
        catch (Exception e){
            return false;
        }
    }

    public boolean recordAdd(int user_id, int sub_id, int amount) throws SQLException {
            String stat = "insert into Wallet(user_id, sub_id, expenses) values(?,?,?)"; //prepared statement to create new user
            try {
                PreparedStatement preparedStatement = con.prepareStatement(stat);//pass the query through connection
                preparedStatement.setInt(1, user_id);//input and pass values
                preparedStatement.setInt(2, sub_id);
                preparedStatement.setInt(3, amount);
                if (preparedStatement.executeUpdate() > 0) {//in case everything went smoothly return true
                    return true;
                }
                preparedStatement.close();
            } catch (SQLException e) { //in case exception occurs return it
                e.printStackTrace();//catch block to be able to respond to the errors and fix the code.
            }

        return false;//return false in case something went wrong
    }

    public boolean recordRemove(int user_id, int sub_id){
        String sql = "delete from wallet where user_id=? and sub_id=?";//query for deleting item from database
        try {
            PreparedStatement preparedStatement = con.prepareStatement(sql);//pass query through connection
            preparedStatement.setInt(1, user_id);//deleting by accessing id
            preparedStatement.setInt(2, sub_id);//deleting by accessing sub id
            if (preparedStatement.executeUpdate() > 0) { //if deleting went successfully return true
                return true;
            }
            preparedStatement.close();
        } catch (SQLException e) {//catching exception in case error
            e.printStackTrace();
        }
        return false;//return false otherwise

    }


    public void showCategories() throws SQLException {
        String stat = "SELECT name FROM categories";
        Statement st = con.createStatement();//establish connection
        ResultSet rs = st.executeQuery(stat);
        int index = 1;
        if(rs.next()) {//do if exists in the table
            do{

                System.out.println(index +". " + rs.getString(1));
                index ++;
            }while(rs.next());
        }
        else{
            System.out.println("Error....");//if values does not exist
        }
    }


    public boolean showSubcategories(int parent) throws SQLException {
        String stat = "SELECT name FROM subcategories WHERE parent_id =" + parent;
        Statement st = con.createStatement();//establish connection
        ResultSet rs = st.executeQuery(stat);
        int index = 1;
        if(rs.next()) {//do if exists in the table
            do {
                System.out.println(index + ". " + rs.getString(1));
                index++;
            }
            while(rs.next());
        }
        else{
            System.out.println("Error....");//if values does not exist
            return false;
        }
        return true;
    }

    public String returnSub(int parent, int ind) throws SQLException {
        String stat = "SELECT name FROM subcategories WHERE parent_id =" + parent;
        Statement st = con.createStatement();//establish connection
        ResultSet rs = st.executeQuery(stat);
        int k = 0;
        String current = " ";
        if(rs.next()) {
            do{
                k++;
                current = rs.getString(1);
            }
            while(k < ind);
        }
        return current;
    }

    public int returnSubId(String sub) throws SQLException {
        String stat = "SELECT sub_id from subcategories WHERE name=" + "'" + sub + "'";
        Statement st = con.createStatement();
        ResultSet rs = st.executeQuery(stat);
        if(rs.next()) {
            return rs.getInt(1);
        }
        else{
            System.out.println("Subcategory does not exist!");
        }
        return rs.getInt(1);
    }

    public String returnRecName(int user_id, int ind) throws SQLException {
        String stat = "SELECT s.name FROM Wallet AS W INNER JOIN subcategories AS S ON  w.sub_id=s.sub_id INNER JOIN categories AS C ON S.parent_id = c.categories_id WHERE W.user_id =" + user_id;
        Statement st = con.createStatement();//establish connection
        ResultSet rs = st.executeQuery(stat);
        int k = 0;
        String current = " ";
        if(rs.next()) {
            do{
                k++;
                current = rs.getString(1);
            }
            while(k != ind);
        }
        else{
            System.out.println("Error...");
        }


        return rs.getString(1);
    }


}