package com.example.navigationdrawer.ui.manual;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class ManualViewModel extends ViewModel {

    private MutableLiveData<String> mText;

    public ManualViewModel() {
        mText = new MutableLiveData<>();
        mText.setValue("The text of the manual goes here");
    }

    public LiveData<String> getText() {
        return mText;
    }
}