package com.company;

import java.util.Random;

public class User {

    private int id;
    private String username;
    private String password;
    private String email;

    public User(){}


    public String get_username() {
        return username;
    }

    public void set_username(String username) {
        this.username = username;
    }

    public String get_password() {
        return password;
    }

    public void set_password(String password) {
        this.password = password;
    }

    public String get_email() {
        return email;
    }

    public void set_email(String email) {
        this.email = email;
    }

    public int id_generator(User user){
        Random num = new Random();
        int numb=0;
        for(int i = 1; i<2;i++){
            numb = 1+num.nextInt(999);
            user.id = numb;
        }
        return user.id;
    }


    public void print_all (User user){
        System.out.println("Username: "+user.get_username());
        System.out.println("Password: "+user.get_password());
        System.out.println("Email: "+user.get_email());
    }

}