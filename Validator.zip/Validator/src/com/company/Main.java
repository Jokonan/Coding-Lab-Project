package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scr = new Scanner(System.in);
        User user1 = new User();
        Validator val = new Validator();

        user1.set_username(scr.nextLine());
        while (!val.check_username(user1.get_username())){
            user1.set_username(scr.nextLine());
        }

        user1.set_password(scr.nextLine());
        while (!val.check_password(user1.get_password())){
            user1.set_password(scr.nextLine());
        }

        user1.set_email((scr.nextLine()));
        while (!val.check_email(user1.get_email())){
            user1.set_email((scr.nextLine()));
        }

        user1.print_all(user1);
        System.out.println("Your id_number is: "+user1.id_generator(user1));
    }
}