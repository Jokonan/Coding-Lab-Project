package com.company;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Validator {

    public boolean check_username (String username) {
        boolean valid = false;
        while (!valid) {
            if (username.isEmpty() || username.isBlank()) {
                System.out.println("You can't leave this field empty!");
                valid=false;
                break;
            } else if (username.length() >= 24) {
                System.out.println("Your username can't be 24 characters or longer!");
                valid=false;
                break;
            } else if (username.length() <= 4) {
                System.out.println("Your username can't be shorter than 5 characters!");
                valid=false;
                break;
            }
            else valid=true;
        }
        if(valid){
            System.out.println("Hello, "+ username+"!");
        }
        return valid;
    }



    public boolean check_password(String pass)
    {
        String regex = "^(?=.*[0-9])"
                + "(?=.*[a-z])(?=.*[A-Z])"
                + "(?=.*[@#$%^&+=])"
                + "(?=\\S+$).{8,20}$"; //using to regular expressions to search through text to find matches

        Pattern pt = Pattern.compile(regex);//creating pattern by calling static compile method passing regex

        if (pass == null) { //if password is empty return false
            System.out.println("Can't leave this field empty!");
            return false;
        }

        Matcher mt = pt.matcher(pass); //what we are going to match to our regex

        if (mt.matches()){
            System.out.println("Valid password!");
        }
        else {
            System.out.println("Invalid password!");
        }
        return mt.matches();//return the result
    }


    public boolean check_email(String email)
    {
        String regex = "^[a-zA-Z0-9_!#$%&'*+/=?`{|}~^.-]+@[a-zA-Z0-9.-]+$";
        Pattern ptt = Pattern.compile(regex);
        if (email == null) {
            return false;
        }
        Matcher mt = ptt.matcher(email);
        if (mt.matches()){
            System.out.println("Valid email!");
        }
        else {
            System.out.println("Invalid email!");
        }
        return mt.matches();
    }
}